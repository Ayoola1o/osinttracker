import React from 'react';
import { Search, Shield, Database, BookOpen, Github } from 'lucide-react';
import Header from './components/Header';
import SearchSection from './components/SearchSection';
import ResultsSection from './components/ResultsSection';
import Footer from './components/Footer';

function App() {
  const [searchQuery, setSearchQuery] = React.useState('');
  const [searchResults, setSearchResults] = React.useState<any[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);

  const handleSearch = async (query: string) => {
    setIsLoading(true);
    setSearchQuery(query);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Mock results
    setSearchResults([
      { id: 1, type: 'email', value: 'example@domain.com', source: 'Public Records' },
      { id: 2, type: 'domain', value: 'domain.com', source: 'WHOIS Database' },
      { id: 3, type: 'social', value: '@username', source: 'Social Media' },
    ]);
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-gray-100">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
            OSINT Research Tool
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Powerful open-source intelligence gathering platform for security researchers and analysts
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {[
            { icon: Search, title: 'Advanced Search', description: 'Comprehensive search across multiple data sources' },
            { icon: Shield, title: 'Secure', description: 'Privacy-focused with encrypted connections' },
            { icon: Database, title: 'Rich Data', description: 'Access to extensive OSINT databases' },
            { icon: BookOpen, title: 'Documentation', description: 'Detailed guides and best practices' },
          ].map((feature, index) => (
            <div key={index} className="bg-gray-800 rounded-lg p-6 hover:bg-gray-700 transition-colors">
              <feature.icon className="w-12 h-12 text-blue-400 mb-4" />
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </div>
          ))}
        </div>

        <SearchSection onSearch={handleSearch} />
        <ResultsSection results={searchResults} isLoading={isLoading} />
      </main>

      <Footer />
    </div>
  );
}

export default App;