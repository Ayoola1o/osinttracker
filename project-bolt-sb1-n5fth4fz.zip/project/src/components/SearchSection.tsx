import React from 'react';
import { Search, Filter } from 'lucide-react';

interface SearchSectionProps {
  onSearch: (query: string) => void;
}

const SearchSection: React.FC<SearchSectionProps> = ({ onSearch }) => {
  const [query, setQuery] = React.useState('');
  const [showFilters, setShowFilters] = React.useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(query);
  };

  return (
    <section className="mb-12">
      <form onSubmit={handleSubmit} className="max-w-4xl mx-auto">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Enter domain, email, username, or keyword..."
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-white placeholder-gray-400"
            />
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          </div>
          
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setShowFilters(!showFilters)}
              className="px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg hover:bg-gray-600 transition-colors relative"
            >
              <Filter className="w-5 h-5" />
              {showFilters && (
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full"></span>
              )}
            </button>
            <button
              type="submit"
              className="flex-1 md:flex-none px-8 py-3 bg-blue-500 rounded-lg hover:bg-blue-600 transition-colors font-medium"
            >
              Search
            </button>
          </div>
        </div>

        {showFilters && (
          <div className="flex flex-wrap gap-4 mt-4 p-4 bg-gray-700 rounded-lg animate-fade-in">
            {['Emails', 'Domains', 'Social Media', 'Public Records'].map((filter) => (
              <label key={filter} className="flex items-center space-x-2">
                <input type="checkbox" className="form-checkbox text-blue-500" />
                <span className="text-sm text-gray-300">{filter}</span>
              </label>
            ))}
          </div>
        )}
      </form>
    </section>
  );
};

export default SearchSection;