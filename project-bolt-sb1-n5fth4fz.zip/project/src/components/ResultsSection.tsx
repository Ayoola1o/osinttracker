import React from 'react';
import { Mail, Globe, Users, AlertCircle, Loader } from 'lucide-react';

interface Result {
  id: number;
  type: string;
  value: string;
  source: string;
}

interface ResultsSectionProps {
  results: Result[];
  isLoading: boolean;
}

const ResultsSection: React.FC<ResultsSectionProps> = ({ results, isLoading }) => {
  const getIcon = (type: string) => {
    switch (type) {
      case 'email':
        return Mail;
      case 'domain':
        return Globe;
      case 'social':
        return Users;
      default:
        return AlertCircle;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader className="w-8 h-8 animate-spin text-blue-500" />
        <span className="ml-3 text-lg">Searching...</span>
      </div>
    );
  }

  if (results.length === 0) {
    return null;
  }

  return (
    <section className="bg-gray-800 rounded-lg p-6">
      <h2 className="text-2xl font-semibold mb-6">Search Results</h2>
      
      <div className="grid gap-4">
        {results.map((result) => {
          const Icon = getIcon(result.type);
          
          return (
            <div
              key={result.id}
              className="bg-gray-700 rounded-lg p-4 hover:bg-gray-600 transition-colors"
            >
              <div className="flex items-start">
                <div className="p-2 bg-gray-600 rounded-lg">
                  <Icon className="w-6 h-6 text-blue-400" />
                </div>
                
                <div className="ml-4 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-medium">{result.value}</span>
                    <span className="text-sm text-gray-400">{result.type}</span>
                  </div>
                  <p className="text-sm text-gray-400 mt-1">
                    Source: {result.source}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};

export default ResultsSection;